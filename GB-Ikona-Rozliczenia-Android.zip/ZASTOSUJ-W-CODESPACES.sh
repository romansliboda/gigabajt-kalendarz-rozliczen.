#!/usr/bin/env bash
set -e
unzip -o GB-Ikona-Rozliczenia-Android.zip "android-apk/*"
git add android-apk/app/src/main/AndroidManifest.xml android-apk/app/src/main/res
git commit -m "Ikona i nazwa GB Rozliczenia"
git push origin main
